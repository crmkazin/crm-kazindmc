<!DOCTYPE html>
<html lang="en">
<head>
    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
	<!-- icons -->
	<link href="https://checkmysite.co.in/crm/assets/admin/plugins/summernote/summernote.css" rel="stylesheet" type="text/css" />
    <link href="https://checkmysite.co.in/crm/assets/admin/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
    <link href="https://checkmysite.co.in/crm/assets/admin/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<!--bootstrap -->
	<link href="https://checkmysite.co.in/crm/assets/admin/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Material Design Lite CSS -->
	<link rel="stylesheet" href="https://checkmysite.co.in/crm/assets/admin/plugins/material/material.min.css">
	<link rel="stylesheet" href="https://checkmysite.co.in/crm/assets/admin/css/material_style.css">
	<link rel="stylesheet" href="https://checkmysite.co.in/crm/assets/admin/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.css">
	<!-- animation -->
	<link href="https://checkmysite.co.in/crm/assets/admin/css/pages/animate_page.css" rel="stylesheet">
	<!-- Template Styles -->
    <link href="https://checkmysite.co.in/crm/assets/admin/css/style.css" rel="stylesheet" type="text/css" />
    <link href="https://checkmysite.co.in/crm/assets/admin/css/plugins.min.css" rel="stylesheet" type="text/css" />
    <link href="https://checkmysite.co.in/crm/assets/admin/css/responsive.css" rel="stylesheet" type="text/css" />
	<link href="https://checkmysite.co.in/crm/assets/admin/css/theme-color.css" rel="stylesheet" type="text/css" />
	<!-- dropzone -->
    <link href="https://checkmysite.co.in/crm/assets/admin/plugins/dropzone/dropzone.css" rel="stylesheet" media="screen">
 
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>

    <script> 
    window.onload = function () {
 
    var url = $(location).attr('href');
    var segments = url.split( '/' );
    var id = segments[4]; 
    var element = document.getElementById('print');
    var opt = {
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 1 },
      jsPDF:        { unit: 'mm', format: 'letter', orientation: 'portrait' }
    };
    //html2pdf().from(element).set(opt).save();
    html2pdf().from(element).set(opt).toPdf().output('datauristring').then(function (pdfAsString) {
        // The PDF has been converted to a Data URI string and passed to this function.
    var arr = pdfAsString.split(',');
    pdfAsString= arr[1];    
    
					$.ajax({
							 url:"https://checkmysite.co.in/crm/handle-pdf",
							 type:"post",
							 data:{ pdf_data:pdfAsString,
							 		id:id
							 		},
							 success: function(dataResult){
							 	var dataResult=JSON.parse(dataResult);
							 	if(dataResult.statusCode==200)// if data is proccessed on server 
							 	{
							 	window.location.href = 'https://checkmysite.co.in/crm/sent-quotations';
							 	}
							 	else if(dataResult.statusCode==201)//if data process failed
							 	{
                                window.location.href = 'https://checkmysite.co.in/crm/sent-quotations';
							 	}
							 }
					});    
    /*
            var data = new FormData();
            data.append("data" , pdfAsString);
            data.append("id" ,id);
            var xhr = new XMLHttpRequest();
            xhr.open( 'post', 'https://checkmysite.co.in/crm/handle-pdf', true ); //Post the Data URI to php Script to save to server
            xhr.send(data); */
        
            }) 
    //window.location.href = 'https://checkmysite.co.in/crm/sent-quotations'; 
    }        
    </script> 
<style>
    .table-checkable{}
    @media print{
      .table-checkable{} 
      .table-checkable p{line-height:20px !important;margin-bottom:5px !important;font-size:14px;padding:0 !important;}
    }
    
</style>
 </head>
 <!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white dark-sidebar-color logo-dark">
<!--    <div class="page-wrapper">
        
        <div class="page-container">

            <div class="page-content-wrapper">
                <div class="page-content"> -->
			
                     <div class="row">
                        <div class="col-md-12">
                            <div class="card card-box" id="print" style="border-bottom:0px !important;">
                                <div class="card-body">
                                    
                                    <table class="table table-hover table-checkable order-column full-width">
                                        <thead>
                                            <tr>
												<th style="text-align: left;"><img src="https://checkmysite.co.in/crm/assets/images/logo.png" style="width:300px;"></th>
												<th style="text-align: right;">PAN : AAJCA0972F <br>CIN :U29128DL2011PTC212297</th>
                                            </tr>
                                        </thead>
                                    </table>
                                
                                <p style="line-height:20px !important;margin-bottom:5px !important;font-size:14px;padding:0 !important;">Ref.No : <?=$detail[0]->quotation_number?></p>
                                <p style="line-height:20px !important;margin-bottom:5px !important;font-size:14px;padding:0 !important;">Kind Attn : <?=$detail[0]->contact_person;?><?php if(!empty($detail[0]->person_designation)){?><br>Designation : <?=$detail[0]->person_designation;?><?php }?> <br><?=$detail[0]->organization;?> <br><?=$detail[0]->address.','.$detail[0]->city.','.$detail[0]->state.','.$detail[0]->country?></p>
                                <p style="line-height:20px !important;margin-bottom:15px !important;font-size:14px;padding:0 !important;">Sub   : <?=$detail[0]->email_subject;?></p>
                                <p style="line-height:20px !important;margin-bottom:15px !important;font-size:14px;padding:0 !important;">Dear Sir/Madam,<br><br> We thankfully acknowledge your above referred enquiry and take pleasure in quoting as per under mentioned terms and conditions - </p>
                                    <table id="Table1" class="table table-hover table-checkable order-column full-width" border="1" border-cossapse="collapse">
                                        <thead>
                                            <tr>
												<th class="center">No.</th>
												<th class="center">Item Description</th>
												<th class="center">Unit Price (<?=$detail[0]->currency;?>)</th>
												<th class="center">Quantity</th>
												<th class="center">Amount (<?=$detail[0]->currency;?>)</th> 
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $i =1; foreach($detail as $data){?>    
                                            <tr>
                                                <td class="center" style="line-height:20px !important;padding-top:5px !important;padding-bottom:5px !important;"><?=$i?></td>
                                                <td class="center" style="line-height:20px !important;padding-top:5px !important;padding-bottom:5px !important;"><?php echo $data->enquiry; if(!empty($data->model)){ echo '<br>Model -'.$data->model;} if(!empty($data->make)){ echo '<br>Make -'.$data->make; } if(!empty($data->description)){ echo '<br><p style="text-align: justify;">'.$data->description.'</p>';}?>
                                                </td>                                                
                                                <td class="center" style="line-height:20px !important;padding-top:5px !important;padding-bottom:5px !important;"><?=preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,", $data->unit_price); ?></td>
                                                <td class="center" style="line-height:20px !important;padding-top:5px !important;padding-bottom:5px !important;"><?=$data->quantity?></td>
                                                <td class="center" style="line-height:20px !important;padding-top:5px !important;padding-bottom:5px !important;"><?=preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,", $data->amount);?></td>
                                            </tr>
                                        <?php $i++; } ?>    
                                        </tbody> 
                                    </table>                                
                                <!--<div style="page-break-before:always">&nbsp;</div> -->
                                <b><u>Term and Conditions :</u></b>
                                    <table class=" full-width">
                                        <tr>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;font-weight:bold;">Price:</td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;" width="300"><?=$detail[0]->price?></td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;font-weight:bold;">Payment:</td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;"><?=$detail[0]->payment?></td>
                                        </tr>
                                        <tr>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;font-weight:bold;">GST:</td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;"><?=$detail[0]->gst?></td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;font-weight:bold;">Freight:</td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;">Extra as applicable</td>
                                        </tr>
                                        <tr>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;font-weight:bold;">Validity: </td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;"><?=$detail[0]->validity?></td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;font-weight:bold;">Installation:</td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;">Extra as applicable if required at your location</td>
                                        </tr>
                                        <tr>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;font-weight:bold;">Delivery: </td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;"> <?=$detail[0]->delivery?></td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;font-weight:bold;">Warranty:</td>
                                            <td style="line-height:20px !important;margin-bottom:0px !important;font-size:14px;padding:0 !important;"><?=$detail[0]->warranty?></td>
                                        </tr>
                                        
                                    </table>
                              <br>
                              <p style="line-height:14px !important;margin-bottom:0px !important;margin-top:0px !important;font-size:14px;padding:0 !important;">&nbsp;</p>
                                <p style="line-height:14px !important;margin-bottom:5px !important;margin-top:15px !important;font-size:14px;padding:0 !important;">Hope above-mentioned is meeting your requirements. Please feel free to revert for any further assistance.</p>
                                 <p style="line-height:14px !important;margin-bottom:0px !important;margin-top:0px !important;font-size:14px;padding:0 !important;">&nbsp;</p>
                            <p style="line-height:14px !important;margin-bottom:5px !important;font-size:14px;padding:0 !important;"C>Your truly: <br>For Intellitest Solutions Pvt. Ltd.</p>
                                <p style="line-height:14px !important;margin-bottom:5px !important;font-size:14px;padding:0 !important;"C><?=$detail[0]->executive_name?><br>Sales Executive - <?=$detail[0]->executive_mobile?><br><?=$detail[0]->executive_email?></p>
                                <hr style="background:red;height:2px;">
                                    <table class=" full-width" style="position:relative;bottom:0;left:0;border-bottom:none;">
                                        <thead>
                                            <tr>
												<th class="center"></th>
												<th class="center"></th>
                                            </tr>
                                        </thead>
                                        
                                        <tbody> 
                                            <tr>
                                                <td><b>Intellitest Solutions Pvt. Ltd.</b></td>
                                                <td style="text-align: right;font-size:13px;"> </td> 
                                            </tr>
                                            <tr>
                                                <td style="font-size:13px;">Corp Office - 12A08, Bussiness Hub, Sector-81, Faridabad -121107(Delhi NCR)</td>
                                                <td style="text-align: right;font-size:13px;">Telephone : +91-129-4096069</td>
                                            </tr>
                                            <tr>
                                                <td style="font-size:13px;">Regd Office - 119-FF, Vardhman Star City Mall, Sector-7, Dwarka, New Delhi -110075</td>
                                                <td style="text-align: right;font-size:13px;">Mobile : +91-9250059892</td>
                                            </tr>
                                            <tr>
                                                <td style="font-size:13px;">Web : www.intellitest.co.in</td>
                                                <td style="text-align: right;font-size:12px;">Email : solutions@intellitest.co.in<br>Email : intellitestspl@gmail.com</td>
                                            </tr>                                            
                                        </tbody> 
                                        
                                    </table>                                
                                
                                </div>
                            </div>
   
                        </div>
                    </div> 					
					
          <!--      </div>
            </div>

        </div>
        

    </div> -->

    <script src="https://checkmysite.co.in/crm/assets/admin/plugins/jquery/jquery.min.js" ></script>
    <script src="https://checkmysite.co.in/crm/assets/admin/plugins/popper/popper.min.js" ></script>
    <script src="https://checkmysite.co.in/crm/assets/admin/plugins/jquery-blockui/jquery.blockui.min.js" ></script>
	<script src="https://checkmysite.co.in/crm/assets/admin/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    
    <script src="https://checkmysite.co.in/crm/assets/admin/plugins/bootstrap/js/bootstrap.min.js" ></script>
   
	<script src="https://checkmysite.co.in/crm/assets/admin/js/app.js" ></script>
    <script src="https://checkmysite.co.in/crm/assets/admin/js/layout.js" ></script>
	<script src="https://checkmysite.co.in/crm/assets/admin/js/theme-color.js" ></script>
	
    <script src="https://checkmysite.co.in/crm/assets/admin/plugins/datatables/jquery.dataTables.min.js" ></script>
 	<script src="https://checkmysite.co.in/crm/assets/admin/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js" ></script>
 	<script src="https://checkmysite.co.in/crm/assets/admin/js/pages/table/table_data.js" ></script>
	
	<script src="https://checkmysite.co.in/crm/assets/admin/plugins/material/material.min.js"></script>
	<script src="https://checkmysite.co.in/crm/assets/admin/js/pages/ui/animations.js" ></script>
    <!-- end js include path -->	
</body>
</html>